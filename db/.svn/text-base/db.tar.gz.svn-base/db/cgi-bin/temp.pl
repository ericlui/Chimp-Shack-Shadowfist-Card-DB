use lib ("/home/chimpsha/lib");
use Cards;

my $desig = Cards::desig_split("memories");

print $desig;

